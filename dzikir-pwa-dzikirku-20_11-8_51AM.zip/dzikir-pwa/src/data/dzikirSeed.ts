export type DzikirCategory = 'sholat' | 'harian' | 'ketenangan'

export type MeaningLevel = 1 | 2 | 3

export interface DzikirMeanings {
  /** Makna inti (bahasa). Terbuka sejak hitungan 0. */
  level1: string
  /** Manfaat & keutamaan. Terbuka di 100 hitungan seumur hidup. */
  level2: string
  /** Refleksi praktis harian. Terbuka di 333 hitungan seumur hidup. */
  level3: string
}

export interface DzikirItem {
  id: string
  title: string
  category: DzikirCategory
  arabic: string
  transliteration: string
  translation: string
  defaultTarget: number
  sourceRef: string
  meanings: DzikirMeanings
}

export const DEFAULT_DZIKIR_ID = 'tasbih'

/** Ambang hitungan seumur hidup untuk membuka tiap level makna. */
export const LEVEL_THRESHOLDS: Record<MeaningLevel, number> = {
  1: 0,
  2: 100,
  3: 333,
}

export const CATEGORY_LABELS: Record<DzikirCategory, string> = {
  sholat: 'Sholat',
  harian: 'Harian',
  ketenangan: 'Ketenangan',
}

export function getUnlockedLevel(lifetimeCount: number): MeaningLevel {
  if (lifetimeCount >= LEVEL_THRESHOLDS[3]) return 3
  if (lifetimeCount >= LEVEL_THRESHOLDS[2]) return 2
  return 1
}

export const DZIKIR_SEED: DzikirItem[] = [
  {
    id: 'tasbih',
    title: 'Tasbih',
    category: 'sholat',
    arabic: 'سُبْحَانَ اللّٰهِ',
    transliteration: 'Subhanallah',
    translation: 'Maha Suci Allah.',
    defaultTarget: 33,
    sourceRef: 'HR. Bukhari & Muslim',
    meanings: {
      level1:
        "Subhanallah berarti 'Maha Suci Allah': menyucikan Allah dari segala kekurangan, cela, dan sifat yang tidak layak bagi-Nya.",
      level2:
        'Termasuk kalimat yang ringan di lisan namun berat di timbangan amal. Setelah shalat, tasbih 33x bersama tahmid 33x dan takbir 34x adalah amalan yang dianjurkan Nabi ﷺ.',
      level3:
        'Saat kagum pada alam, atau saat tergoda mengeluh, ucapkan tasbih untuk mengingat bahwa Allah Maha Sempurna dan rencana-Nya tidak pernah cacat. Jadikan ia jeda kecil sebelum bereaksi.',
    },
  },
  {
    id: 'tahmid',
    title: 'Tahmid',
    category: 'sholat',
    arabic: 'اَلْحَمْدُ لِلّٰهِ',
    transliteration: 'Alhamdulillah',
    translation: 'Segala puji bagi Allah.',
    defaultTarget: 33,
    sourceRef: 'HR. Muslim',
    meanings: {
      level1:
        "Alhamdulillah berarti 'Segala puji bagi Allah': pengakuan bahwa semua nikmat dan kebaikan bersumber dari-Nya.",
      level2:
        'Rasulullah ﷺ menyebut bahwa alhamdulillah memenuhi timbangan amal. Syukur juga menjadi sebab bertambahnya nikmat (QS. Ibrahim: 7).',
      level3:
        'Sebelum tidur, ingat tiga hal kecil yang patut disyukuri hari ini, lalu ucapkan alhamdulillah untuk masing-masing. Syukur yang dilatih membuat hati lebih lapang.',
    },
  },
  {
    id: 'takbir',
    title: 'Takbir',
    category: 'sholat',
    arabic: 'اَللّٰهُ أَكْبَرُ',
    transliteration: 'Allahu Akbar',
    translation: 'Allah Maha Besar.',
    defaultTarget: 34,
    sourceRef: 'HR. Muslim',
    meanings: {
      level1:
        "Allahu Akbar berarti 'Allah Maha Besar': lebih besar dari semua masalah, rasa takut, dan keinginan kita.",
      level2:
        'Takbir menyempurnakan hitungan 100 dzikir setelah shalat (33 tasbih, 33 tahmid, 34 takbir). Ia juga termasuk empat kalimat yang paling dicintai Allah.',
      level3:
        'Ketika sebuah beban terasa terlalu besar, ucapkan takbir dan ingat bahwa ada Zat yang lebih besar dari beban itu. Latih diri mengecilkan masalah dengan mengagungkan-Nya.',
    },
  },
  {
    id: 'istighfar',
    title: 'Istighfar',
    category: 'ketenangan',
    arabic: 'أَسْتَغْفِرُ اللّٰهَ',
    transliteration: 'Astaghfirullah',
    translation: 'Aku memohon ampun kepada Allah.',
    defaultTarget: 100,
    sourceRef: 'HR. Bukhari & Muslim',
    meanings: {
      level1:
        "Astaghfirullah berarti 'Aku memohon ampun kepada Allah': pengakuan atas kelemahan diri dan kebutuhan akan ampunan-Nya.",
      level2:
        'Nabi ﷺ beristighfar sekitar 70 hingga 100 kali sehari. Allah juga menjanjikan keluasan rezeki dan kebaikan bagi hamba yang memohon ampun (QS. Nuh: 10-12).',
      level3:
        'Di akhir hari, ingat satu kesalahan yang ingin kamu perbaiki, beristighfarlah dengan tulus, lalu maafkan dirimu dengan niat berbenah. Pintu taubat selalu terbuka.',
    },
  },
  {
    id: 'tahlil',
    title: 'Tahlil',
    category: 'harian',
    arabic: 'لَا إِلٰهَ إِلَّا اللّٰهُ',
    transliteration: 'La ilaha illallah',
    translation: 'Tiada tuhan yang berhak disembah selain Allah.',
    defaultTarget: 100,
    sourceRef: 'HR. Tirmidzi & Bukhari',
    meanings: {
      level1:
        "La ilaha illallah berarti 'Tiada tuhan yang berhak disembah selain Allah': inti tauhid dan fondasi keimanan.",
      level2:
        'Rasulullah ﷺ bersabda bahwa dzikir yang paling utama adalah La ilaha illallah (HR. Tirmidzi). Orang yang paling berbahagia dengan syafaat beliau adalah yang mengucapkannya ikhlas dari hatinya (HR. Bukhari).',
      level3:
        'Saat bergantung pada banyak hal (pekerjaan, penilaian orang, hasil), ucapkan tahlil untuk menata ulang hati: hanya Allah tempat bergantung yang sebenarnya. Lepaskan satu kekhawatiran hari ini.',
    },
  },
  {
    id: 'ayat-kursi',
    title: "Ta'awudz & Ayat Kursi",
    category: 'ketenangan',
    arabic: 'أَعُوذُ بِاللَّهِ مِنْ الشَّيْطَانِ الرَّجِيمِ اللَّهُ لاَ إِلَهَ إِلاَّ هُوَ الْحَيُّ الْقَيُّومُ، لاَ تَأْخُذُهُ سِنَةٌ وَلاَ نَوْمٌ، لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ، مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلاَّ بِإِذْنِهِ، يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ، وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلاَّ بِمَا شَاءَ، وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ، وَلَا يَئُودُهُ حِفْظُهُمَا، وَهُوَ الْعَلِيُّ الْعَظِيمُ',
    transliteration: "A'uudzu billaahi minasy syaithaanir rajiim. Allaahu laa ilaaha illaa huwal hayyul qayyuum...",
    translation: 'Aku berlindung kepada Allah dari syaitan. Allah, tidak ada Ilah selain Dia, Yang Hidup Kekal dan terus mengurus makhluk-Nya.',
    defaultTarget: 1,
    sourceRef: "HR. An-Nasa'i, Ath-Thabrani, Al-Hakim",
    meanings: {
      level1:
        "Ta'awudz adalah permohonan perlindungan kepada Allah dari godaan syaitan yang terkutuk. Ayat Kursi menegaskan keagungan Allah: Dia Yang Hidup Kekal, tidak mengantuk dan tidak tidur, dan kursi-Nya meliputi langit dan bumi.",
      level2:
        "Ayat Kursi dibaca pagi dan petang untuk memohon perlindungan. Haditsnya diriwayatkan An-Nasa'i dalam 'Amalul Yaum wal Lailah dan Ath-Thabrani, serta dinilai shahih oleh Syaikh Al-Albani.",
      level3:
        'Saat merasa rentan atau cemas, ingat bahwa Allah tidak pernah lengah menjaga langit dan bumi. Jadikan ayat ini tempat berlindung sebelum menghadapi hari.',
    },
  },
  {
    id: 'al-ikhlas',
    title: 'Al-Ikhlas',
    category: 'ketenangan',
    arabic: 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ قُلْ هُوَ اللَّهُ أَحَدٌ اللَّهُ الصَّمَدُ لَمْ يَلِدْ وَلَمْ يُولَدْ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ',
    transliteration: "Qul huwallaahu ahad, Allaahush shamad, lam yalid wa lam yuulad, wa lam yakul lahuu kufuwan ahad.",
    translation: 'Katakanlah: Dia-lah Allah Yang Maha Esa.',
    defaultTarget: 3,
    sourceRef: "HR. Abu Dawud, At-Tirmidzi, An-Nasa'i",
    meanings: {
      level1:
        'Surat Al-Ikhlas menegaskan keesaan Allah: Dia Maha Esa, tempat bergantung segala sesuatu, tidak beranak dan tidak diperanakkan, dan tidak ada yang setara dengan-Nya.',
      level2:
        "Bersama Al-Falaq dan An-Naas, surat ini termasuk Al-Mu'awwidzaat yang dibaca pagi dan petang sebagai perlindungan. Haditsnya diriwayatkan Abu Dawud, At-Tirmidzi, dan An-Nasa'i.",
      level3:
        'Saat hati terasa penuh kekhawatiran, ulangi keyakinan bahwa hanya Allah tempat bergantung yang sebenarnya. Jadikan surat ini pengingat bahwa tidak ada sandaran lain yang setara dengan-Nya.',
    },
  },
  {
    id: 'al-falaq',
    title: 'Al-Falaq',
    category: 'ketenangan',
    arabic: 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ مِن شَرِّ مَا خَلَقَ وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ',
    transliteration: "Qul a'uudzu birabbil falaq, min syarri maa khalaq, wa min syarri ghaasiqin idzaa waqab, wa min syarrin naffaatsaati fil 'uqad, wa min syarri haasidin idzaa hasad.",
    translation: 'Aku berlindung kepada Rabb yang menguasai waktu Subuh, dari kejahatan makhluk-Nya.',
    defaultTarget: 3,
    sourceRef: "HR. Abu Dawud, At-Tirmidzi, An-Nasa'i",
    meanings: {
      level1:
        'Surat Al-Falaq memohon perlindungan kepada Rabb yang menguasai waktu Subuh dari berbagai kejahatan: kejahatan makhluk-Nya, malam yang gelap gulita, tukang sihir yang meniup pada buhul, dan kedengkian orang yang dengki.',
      level2:
        "Termasuk Al-Mu'awwidzaat yang dibaca pagi dan petang bersama Al-Ikhlas dan An-Naas. Haditsnya diriwayatkan Abu Dawud, At-Tirmidzi, dan An-Nasa'i, dan dinilai hasan shahih oleh At-Tirmidzi.",
      level3:
        "Setiap kali merasa iri atau terganggu oleh niat buruk orang lain, mintalah perlindungan kepada Allah. Lalu doakan kebaikan bagi orang tersebut, agar hati tetap bersih.",
    },
  },
  {
    id: 'an-naas',
    title: 'An-Naas',
    category: 'ketenangan',
    arabic: 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ قُلْ أَعُوذُ بِرَبِّ النَّاسِ مَلِكِ النَّاسِ إِلَهِ النَّاسِ مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ مِنَ الْجِنَّةِ وَ النَّاسِ',
    transliteration: "Qul a'uudzu birabbin naas, malikin naas, ilaahin naas, min syarril waswaasil khannaas, alladzii yuwaswisu fii shuduurin naas, minal jinnati wan naas.",
    translation: 'Aku berlindung kepada Rabb, Raja, dan Sembahan manusia, dari kejahatan bisikan syaitan yang bersembunyi.',
    defaultTarget: 3,
    sourceRef: "HR. Abu Dawud, At-Tirmidzi, An-Nasa'i",
    meanings: {
      level1:
        'Surat An-Naas memohon perlindungan kepada Allah sebagai Rabb, Raja, dan Sembahan manusia, dari bisikan syaitan yang bersembunyi dan membisikkan keburukan ke dalam dada manusia, baik dari golongan jin maupun manusia.',
      level2:
        "Termasuk Al-Mu'awwidzaat yang dibaca pagi dan petang bersama Al-Ikhlas dan Al-Falaq. Haditsnya diriwayatkan Abu Dawud, At-Tirmidzi, dan An-Nasa'i.",
      level3:
        'Saat pikiran dipenuhi bisikan yang meresahkan, berlindunglah kepada Rabb manusia, lalu tenangkan hati dengan menyebut nama-Nya.',
    },
  },
  {
    id: 'pagi-memasuki',
    title: 'Memasuki Pagi',
    category: 'harian',
    arabic: 'أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لاَ إِلَـهَ إِلاَّ اللهُ وَحْدَهُ لاَ شَرِيْكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيْرُ. رَبِّ أَسْأَلُكَ خَيْرَ مَا فِيْ هَذَا الْيَوْمِ وَخَيْرَ مَا بَعْدَهُ، وَأَعُوْذُ بِكَ مِنْ شَرِّ مَا فِيْ هَذَا الْيَوْمِ وَشَرِّ مَا بَعْدَهُ، رَبِّ أَعُوْذُ بِكَ مِنَ الْكَسَلِ وَسُوْءِ الْكِبَرِ، رَبِّ أَعُوْذُ بِكَ مِنْ عَذَابٍ فِي النَّارِ وَعَذَابٍ فِي الْقَبْرِ',
    transliteration: 'Ashbahnaa wa ashbahal mulku lillaah, walhamdu lillaah, laa ilaaha illallaahu wahdahu laa syariikalah...',
    translation: 'Kami memasuki waktu pagi, kerajaan hanya milik Allah, dan segala puji bagi Allah.',
    defaultTarget: 1,
    sourceRef: 'HR. Muslim',
    meanings: {
      level1:
        'Pengakuan bahwa kita memasuki pagi dalam kekuasaan Allah. Dzikir ini memohon kebaikan hari ini dan sesudahnya, serta perlindungan dari kejahatannya, dari kemalasan, dari kejelekan di masa tua, dan dari siksa neraka serta kubur.',
      level2:
        "Dibaca sekali di pagi hari sebagai pengakuan bahwa segala kerajaan dan pujian hanya milik Allah. Haditsnya diriwayatkan Muslim dari Ibnu Mas'ud.",
      level3:
        'Sebelum aktivitas dimulai, ucapkan dzikir ini untuk menata niat: memohon kebaikan hari ini dan menjauh dari hal yang melalaikan, termasuk kemalasan.',
    },
  },
  {
    id: 'sore-memasuki',
    title: 'Memasuki Sore',
    category: 'harian',
    arabic: 'أَمْسَيْنَا وَأَمْسَى الْمُلْكُ للهِ، وَالْحَمْدُ للهِ، لَا إِلَهَ إِلاَّ اللهُ وَحْدَهُ لاَ شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ، وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هَذِهِ اللَّيْلَةِ وَخَيْرَ مَا بَعْدَهَا، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هَذِهِ اللَّيْلَةِ وَشَرِّ مَا بَعْدَهَا، رَبِّ أَعُوذُ بِكَ مِنَ الْكَسَلِ وَسُوءِ الْكِبَرِ، رَبِّ أَعُوذُ بِكَ مِنْ عَذَابٍ فِي النَّارِ وَعَذَابٍ فِي الْقَبْرِ',
    transliteration: 'Amsainaa wa amsal mulku lillaah, walhamdu lillaah, laa ilaaha illallaahu wahdahu laa syariikalah...',
    translation: 'Kami memasuki waktu sore, kerajaan hanya milik Allah, dan segala puji bagi Allah.',
    defaultTarget: 1,
    sourceRef: 'HR. Muslim',
    meanings: {
      level1:
        'Pengakuan yang sama seperti dzikir pagi, dengan memohon kebaikan malam ini dan sesudahnya, serta perlindungan dari kejahatan malam ini dan sesudahnya, dari kemalasan, dan dari siksa neraka serta kubur.',
      level2:
        "Melengkapi dzikir pagi, dzikir sore ini dibaca sekali di waktu petang sebagai pengakuan atas kekuasaan Allah di malam hari. Haditsnya diriwayatkan Muslim dari Ibnu Mas'ud.",
      level3:
        'Di penghujung hari, kembalikan segala beban dan rencana kepada Allah. Tidur dengan hati yang lebih ringan karena tahu siapa yang mengatur malam ini.',
    },
  },
  {
    id: 'pagi-berserah',
    title: 'Berserah Diri Pagi',
    category: 'harian',
    arabic: 'اَللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوْتُ وَإِلَيْكَ النُّشُوْرُ',
    transliteration: "Allaahumma bika ashbahnaa, wa bika amsainaa, wa bika nahyaa, wa bika namuutu, wa ilaikan nusyuur.",
    translation: 'Ya Allah, dengan pertolongan-Mu kami memasuki pagi, dan kepada-Mu kebangkitan.',
    defaultTarget: 1,
    sourceRef: "HR. Abu Dawud, At-Tirmidzi, Ibnu Majah",
    meanings: {
      level1:
        'Ya Allah, dengan rahmat dan kehendak-Mu kami memasuki pagi, hidup, dan mati. Dan kepada-Mu kebangkitan. Dzikir ini mengakui bahwa seluruh hidup berada dalam pengaturan Allah.',
      level2:
        "Dzikir ini mengakui bahwa hidup, mati, dan kebangkitan berada dalam genggaman Allah. Diriwayatkan Abu Dawud, At-Tirmidzi, dan Ibnu Majah, serta dishahihkan Syaikh Al-Albani.",
      level3:
        'Setiap pagi, sadari bahwa hari ini adalah pinjaman dari Allah. Jalani setiap urusan dengan sikap berserah, dan jangan merasa memegang kendali penuh.',
    },
  },
  {
    id: 'sore-berserah',
    title: 'Berserah Diri Sore',
    category: 'harian',
    arabic: 'اَللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيْرُ',
    transliteration: "Allaahumma bika amsainaa, wa bika ashbahnaa, wa bika nahyaa, wa bika namuutu, wa ilaikal mashiir.",
    translation: 'Ya Allah, dengan pertolongan-Mu kami memasuki sore, dan kepada-Mu tempat kembali.',
    defaultTarget: 1,
    sourceRef: "HR. Abu Dawud, At-Tirmidzi, Ibnu Majah",
    meanings: {
      level1:
        'Ya Allah, dengan rahmat dan kehendak-Mu kami memasuki sore dan pagi, hidup dan mati, dan kepada-Mu tempat kembali seluruh makhluk.',
      level2:
        "Pasangan dzikir pagi ini diriwayatkan Abu Dawud, At-Tirmidzi, dan Ibnu Majah. Ia menegaskan bahwa hidup, mati, dan kembali kepada Allah berada dalam pengaturan-Nya.",
      level3:
        'Di penghujung hari, serahkan kekhawatiran dan rencana esok kepada Allah. Tidur dengan hati yang lebih ringan karena tahu kepada siapa segalanya kembali.',
    },
  },
  {
    id: 'sayyidul-istighfar',
    title: 'Sayyidul Istighfar',
    category: 'harian',
    arabic: 'اَللَّهُمَّ أَنْتَ رَبِّيْ لاَ إِلَـهَ إِلاَّ أَنْتَ، خَلَقْتَنِيْ وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوْذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوْءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوْءُ بِذَنْبِيْ فَاغْفِرْ لِيْ فَإِنَّهُ لاَ يَغْفِرُ الذُّنُوْبَ إِلاَّ أَنْتَ',
    transliteration: "Allaahumma anta rabbii, laa ilaaha illaa anta, khalaqtanii wa ana 'abduka, wa ana 'alaa 'ahdika wa wa'dika mastatha'tu...",
    translation: 'Ya Allah, Engkau Rabb-ku, tidak ada Ilah selain Engkau. Ampunilah aku, sesungguhnya tidak ada yang mengampuni dosa kecuali Engkau.',
    defaultTarget: 1,
    sourceRef: 'HR. Al-Bukhari dari Syaddad bin Aus',
    meanings: {
      level1:
        'Sayyidul istighfar berarti penghulu istighfar. Isinya pengakuan tauhid, pengakuan bahwa kita hamba-Nya, pengakuan atas nikmat dan dosa, serta permohonan ampun kepada Allah karena tidak ada yang mengampuni dosa selain Dia.',
      level2:
        'Dalam hadits riwayat Al-Bukhari dari Syaddad bin Aus, Nabi ﷺ bersabda bahwa siapa yang mengucapkannya dengan yakin di siang hari lalu meninggal sebelum sore, ia termasuk penghuni surga.',
      level3:
        'Jadikan dzikir ini ringkasan pengakuan harian: aku hamba-Mu, aku berusaha menepati janjiku semampuku, dan aku mengakui dosaku. Setelah itu, lepaskan rasa bersalah dan kembali melangkah.',
    },
  },
  {
    id: 'aafinii',
    title: 'Kesehatan Badan',
    category: 'ketenangan',
    arabic: 'اَللَّهُمَّ عَافِنِيْ فِيْ بَدَنِيْ، اَللَّهُمَّ عَافِنِيْ فِيْ سَمْعِيْ، اَللَّهُمَّ عَافِنِيْ فِيْ بَصَرِيْ، لاَ إِلَـهَ إِلاَّ أَنْتَ. اَللَّهُمَّ إِنِّي أَعُوْذُ بِكَ مِنَ الْكُفْرِ وَالْفَقْرِ، وَأَعُوْذُ بِكَ مِنْ عَذَابِ الْقَبْرِ، لاَ إِلَـهَ إِلاَّ أَنْتَ',
    transliteration: "Allaahumma 'aafinii fii badanii, Allaahumma 'aafinii fii sam'ii, Allaahumma 'aafinii fii bashrii, laa ilaaha illaa anta...",
    translation: 'Ya Allah, selamatkan tubuh, pendengaran, dan penglihatanku. Lindungilah aku dari kekufuran, kefakiran, dan siksa kubur.',
    defaultTarget: 3,
    sourceRef: 'HR. Abu Dawud, Ahmad',
    meanings: {
      level1:
        'Permohonan agar Allah menyelamatkan tubuh, pendengaran, dan penglihatan, serta perlindungan dari kekufuran, kefakiran, dan siksa kubur.',
      level2:
        'Kesehatan adalah nikmat yang sering dilupakan. Dzikir ini dibaca tiga kali pagi dan petang sebagai syukur sekaligus permohonan agar nikmat itu terjaga. Diriwayatkan Abu Dawud dan Ahmad, dan dihasankan oleh Syaikh Al-Albani.',
      level3:
        'Saat tubuh terasa lelah atau mulai mengeluh, syukuri anggota tubuh yang masih berfungsi. Gunakan mata dan telinga hari ini untuk hal-hal yang bermanfaat.',
    },
  },
  {
    id: 'afwa-aafiyah',
    title: 'Perlindungan Dunia & Akhirat',
    category: 'ketenangan',
    arabic: 'اَللَّهُمَّ إِنِّيْ أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي الدُّنْيَا وَاْلآخِرَةِ، اَللَّهُمَّ إِنِّيْ أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي دِيْنِيْ وَدُنْيَايَ وَأَهْلِيْ وَمَالِيْ اللَّهُمَّ اسْتُرْ عَوْرَاتِى وَآمِنْ رَوْعَاتِى. اَللَّهُمَّ احْفَظْنِيْ مِنْ بَيْنِ يَدَيَّ، وَمِنْ خَلْفِيْ، وَعَنْ يَمِيْنِيْ وَعَنْ شِمَالِيْ، وَمِنْ فَوْقِيْ، وَأَعُوْذُ بِعَظَمَتِكَ أَنْ أُغْتَالَ مِنْ تَحْتِيْ',
    transliteration: "Allaahumma innii as-alukal 'afwa wal 'aafiyah fid dunyaa wal aakhirah...",
    translation: 'Ya Allah, aku memohon maaf dan keselamatan di dunia dan akhirat, dalam agama, dunia, keluarga, dan hartaku.',
    defaultTarget: 1,
    sourceRef: "HR. Abu Dawud, An-Nasa'i, Ibnu Majah",
    meanings: {
      level1:
        'Permohonan maaf dan keselamatan di dunia dan akhirat, dalam agama, dunia, keluarga, dan harta. Juga permohonan agar aib ditutupi, rasa takut ditenangkan, dan dijaga dari segala arah, termasuk dari bahaya yang datang dari bawah.',
      level2:
        "Dzikir ini diriwayatkan Abu Dawud, An-Nasa'i, dan Ibnu Majah, serta dinilai shahih oleh Syaikh Al-Albani. Ia termasuk doa yang dianjurkan dibaca pagi dan petang bersama dzikir lainnya.",
      level3:
        'Saat merasa kurang aman, baik di keluarga, pekerjaan, atau keuangan, ingat doa ini. Lakukan usaha yang bertanggung jawab, lalu serahkan hasilnya kepada Allah.',
    },
  },
  {
    id: 'alimal-ghaib',
    title: 'Perlindungan dari Diri & Syaitan',
    category: 'ketenangan',
    arabic: 'اَللَّهُمَّ عَالِمَ الْغَيْبِ وَالشَّهَادَةِ فَاطِرَ السَّمَاوَاتِ وَاْلأَرْضِ، رَبَّ كُلِّ شَيْءٍ وَمَلِيْكَهُ، أَشْهَدُ أَنْ لاَ إِلَـهَ إِلاَّ أَنْتَ، أَعُوْذُ بِكَ مِنْ شَرِّ نَفْسِيْ، وَمِنْ شَرِّ الشَّيْطَانِ وَشِرْكِهِ، وَأَنْ أَقْتَرِفَ عَلَى نَفْسِيْ سُوْءًا أَوْ أَجُرَّهُ إِلَى مُسْلِمٍ',
    transliteration: "Allaahumma 'aalimal ghaibi wasy syahaadah, faathiras samaawaati wal ardh, rabba kulli syai'in wa maliikahu...",
    translation: 'Ya Allah, Yang Maha Mengetahui yang ghaib dan yang nyata. Aku berlindung kepada-Mu dari kejahatan diriku dan syaitan.',
    defaultTarget: 1,
    sourceRef: 'HR. Abu Dawud, At-Tirmidzi',
    meanings: {
      level1:
        'Pengakuan bahwa Allah mengetahui yang ghaib dan yang nyata, serta permohonan perlindungan dari kejahatan diri sendiri, dari godaan syaitan dan balatentaranya, dan dari mencelakai diri atau orang Islam lain.',
      level2:
        'Dzikir ini dibaca pagi dan petang sebagai pengakuan atas ilmu Allah dan perlindungan dari keburukan diri. Diriwayatkan Abu Dawud dan At-Tirmidzi, dan dishahihkan Syaikh Al-Albani dalam Shahih At-Tirmidzi.',
      level3:
        'Saat menyadari diri sedang khilaf atau tergoda keburukan, ingat bahwa tidak ada yang tersembunyi bagi Allah. Mohon perlindungan-Nya, lalu perbaiki satu langkah kecil hari itu.',
    },
  },
  {
    id: 'bismillah-yadhurru',
    title: 'Pelindung dari Bahaya',
    category: 'ketenangan',
    arabic: 'بِسْمِ اللهِ الَّذِي لاَ يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي اْلأَرْضِ وَلاَ فِي السَّمَاءِ وَهُوَ السَّمِيْعُ الْعَلِيْمُ',
    transliteration: "Bismillaahil ladzii laa yadhurru ma'asmihi syai'un fil ardhi wa laa fis samaa'i wa huwas samii'ul 'aliim.",
    translation: 'Dengan nama Allah, yang bersama nama-Nya tidak ada sesuatu pun yang membahayakan, di bumi maupun di langit.',
    defaultTarget: 3,
    sourceRef: 'HR. Abu Dawud, At-Tirmidzi, Ibnu Majah',
    meanings: {
      level1:
        'Dengan menyebut nama Allah, tidak ada sesuatu pun yang dapat membahayakan, baik di bumi maupun di langit. Dia Maha Mendengar dan Maha Mengetahui.',
      level2:
        "Dalam riwayat Abu Dawud dan lainnya, orang yang membacanya tiga kali pagi dan petang tidak akan tertimpa musibah secara mendadak. Dishahihkan Syaikh Al-Albani dalam Shahih Ibni Majah.",
      level3:
        'Sebelum keluar rumah atau memulai pekerjaan, ucapkan dzikir ini dengan sadar. Ia mengingatkan bahwa perlindungan terbaik datang dari Allah, bukan semata dari kekuatan diri sendiri.',
    },
  },
  {
    id: 'radhiitu',
    title: 'Ridha kepada Allah',
    category: 'harian',
    arabic: 'رَضِيْتُ بِاللهِ رَبًّا، وَبِاْلإِسْلاَمِ دِيْنًا، وَبِمُحَمَّدٍ صَلَّى اللهُ عَلَيْهِ وَسَلَّمَ نَبِيًّا',
    transliteration: "Radhiitu billaahi rabbaa, wa bil islaami diinaa, wa bi Muhammadin shallallaahu 'alaihi wa sallam nabiyyaa.",
    translation: 'Aku ridha Allah sebagai Rabb, Islam sebagai agama, dan Muhammad sebagai nabi.',
    defaultTarget: 3,
    sourceRef: 'HR. Ahmad, Abu Dawud, At-Tirmidzi',
    meanings: {
      level1:
        'Ikrar ridha bahwa Allah adalah Rabb, Islam adalah agama, dan Muhammad ﷺ adalah nabi. Ridha berarti menerima dengan lapang hati.',
      level2:
        'Dalam riwayat Abu Dawud, orang yang mengucapkannya tiga kali pagi dan petang mendapat janji keridhaan dari Allah. Dzikir ini juga diriwayatkan Ahmad dan At-Tirmidzi.',
      level3:
        'Setiap pagi dan petang, perbarui komitmen ini. Saat hasil tidak sesuai harapan, ingat bahwa kita sudah ridha kepada Allah sebagai Rabb dan menerima takdir-Nya dengan lapang.',
    },
  },
  {
    id: 'yaa-hayyu',
    title: 'Memohon Pertolongan',
    category: 'ketenangan',
    arabic: 'يَا حَيُّ يَا قَيُّوْمُ بِرَحْمَتِكَ أَسْتَغِيْثُ، أَصْلِحْ لِيْ شَأْنِيْ كُلَّهُ وَلاَ تَكِلْنِيْ إِلَى نَفْسِيْ طَرْفَةَ عَيْنٍ',
    transliteration: "Yaa Hayyu yaa Qayyuumu, birahmatika astaghiits. Ashlih lii sya'nii kullahu, wa laa takilnii ilaa nafsii tharfata 'ain.",
    translation: 'Wahai Rabb Yang Maha Hidup, Yang Berdiri Sendiri, dengan rahmat-Mu aku memohon pertolongan. Perbaikilah seluruh urusanku.',
    defaultTarget: 1,
    sourceRef: "HR. An-Nasa'i, Al-Hakim",
    meanings: {
      level1:
        'Permohonan kepada Allah Yang Maha Hidup dan Berdiri Sendiri agar memperbaiki seluruh urusan, dan tidak menyerahkan diri kepada diri sendiri walau sekejap mata.',
      level2:
        "Dzikir ini mengakui kelemahan diri dan bergantung penuh kepada Allah. Diriwayatkan An-Nasa'i dalam 'Amalul Yaum wal Lailah dan Al-Hakim, serta dishahihkan Syaikh Al-Albani.",
      level3:
        'Saat semua urusan terasa kusut, kerjakan dulu bagian yang bisa kita kendalikan, lalu serahkan sisanya kepada Allah. Tarik napas, dan ucapkan dzikir ini.',
    },
  },
  {
    id: 'fithratil-islam',
    title: 'Fitrah Islam',
    category: 'harian',
    arabic: 'أَصْبَحْنَا عَلَى فِطْرَةِ اْلإِسْلاَمِ وَعَلَى كَلِمَةِ اْلإِخْلاَصِ، وَعَلَى دِيْنِ نَبِيِّنَا مُحَمَّدٍ صَلَّى اللهُ عَلَيْهِ وَسَلَّمَ، وَعَلَى مِلَّةِ أَبِيْنَا إِبْرَاهِيْمَ، حَنِيْفًا مُسْلِمًا وَمَا كَانَ مِنَ الْمُشْرِكِيْنَ',
    transliteration: "Ashbahnaa 'alaa fithratil islaam, wa 'alaa kalimatil ikhlaash, wa 'alaa diini nabiyyinaa Muhammadin shallallaahu 'alaihi wa sallam, wa 'alaa millati abiinaa Ibraahiim, haniifan muslimaa, wa maa kaana minal musyrikiin.",
    translation: 'Kami memasuki pagi di atas fitrah Islam, kalimat ikhlas, agama Nabi kami, dan agama Ibrahim yang lurus.',
    defaultTarget: 1,
    sourceRef: 'HR. Ahmad, Ad-Darimi',
    meanings: {
      level1:
        'Pengakuan bahwa di pagi hari kita berpegang pada fitrah Islam, kalimat ikhlas, agama Nabi Muhammad, dan agama Ibrahim yang lurus, serta tidak termasuk orang musyrik.',
      level2:
        "Fitrah Islam adalah kecenderungan asli manusia untuk mengenal dan menyembah Allah. Dzikir ini khusus dibaca di pagi hari, dan diriwayatkan Ahmad serta Ad-Darimi. Dalam riwayat lain, lafaz 'Amsainaa' juga dibaca di sore hari.",
      level3:
        'Saat bangun pagi, sebelum membuka kabar dan pesan, jadikan kalimat ikhlas sebagai pegangan. Tanyakan pada diri sendiri: apa yang hari ini akan menjaga hati tetap lurus?',
    },
  },
  {
    id: 'tasbih-pagi',
    title: 'Tasbih Pagi',
    category: 'harian',
    arabic: 'سُبْحَانَ اللهِ وَبِحَمْدِهِ: عَدَدَ خَلْقِهِ، وَرِضَا نَفْسِهِ، وَزِنَةَ عَرْشِهِ وَمِدَادَ كَلِمَاتِهِ',
    transliteration: "Subhaanallaahi wa bihamdihi: 'adada khalqihi, wa ridhaa nafsihi, wa zinata 'arsyihi, wa midaada kalimaatihi.",
    translation: 'Mahasuci Allah, aku memuji-Nya sebanyak makhluk-Nya dan sebanyak tinta kalimat-Nya.',
    defaultTarget: 3,
    sourceRef: 'HR. Muslim',
    meanings: {
      level1:
        "Tasbih ini memuji Allah dengan ukuran yang tak terbatas: sebanyak makhluk-Nya, sejauh keridhaan-Nya, seberat timbangan 'Arsy-Nya, dan sebanyak tinta tulisan kalimat-Nya.",
      level2:
        "Dalam riwayat Muslim dari Juwairiyah, Nabi ﷺ menyebut bahwa kalimat ini lebih berat timbangannya dibanding seluruh dzikir yang Juwairiyah baca sejak pagi itu. Dibaca tiga kali khusus di pagi hari.",
      level3:
        'Saat memulai aktivitas pagi, ucapkan dzikir ini perlahan. Ia mengingatkan bahwa pujian kepada Allah tidak ada batasnya, sehingga kita tidak pernah pantas merasa sudah cukup bersyukur.',
    },
  },
  {
    id: 'ilmu-rezeki-amal',
    title: 'Ilmu, Rezeki & Amal',
    category: 'harian',
    arabic: 'اَللَّهُمَّ إِنِّيْ أَسْأَلُكَ عِلْمًا نَافِعًا، وَرِزْقًا طَيِّبًا، وَعَمَلاً مُتَقَبَّلاً',
    transliteration: "Allaahumma innii as-aluka 'ilman naafi'aa, wa rizqan thayyiban, wa 'amalan mutaqabbalaa.",
    translation: 'Ya Allah, aku memohon kepada-Mu ilmu yang bermanfaat, rezeki yang baik, dan amal yang diterima.',
    defaultTarget: 1,
    sourceRef: "HR. Ibnu Majah, An-Nasa'i",
    meanings: {
      level1:
        'Doa memohon tiga hal: ilmu yang bermanfaat, rezeki yang baik dan halal, serta amal yang diterima oleh Allah.',
      level2:
        "Doa ini khusus dibaca di pagi hari, setelah shalat Shubuh. Diriwayatkan Ibnu Majah dan An-Nasa'i, serta dishahihkan Syaikh Al-Albani dalam Shahih Ibni Majah.",
      level3:
        'Saat memulai hari, tanyakan pada diri sendiri: ilmu apa yang ingin dipelajari hari ini, dan amal kecil apa yang bisa dikerjakan dengan ikhlas?',
    },
  },
  {
    id: 'subhanallah-wa-bihamdih',
    title: 'Subhanallah wa Bihamdih',
    category: 'harian',
    arabic: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ',
    transliteration: 'Subhaanallaahi wa bihamdih',
    translation: 'Mahasuci Allah, aku memuji-Nya.',
    defaultTarget: 100,
    sourceRef: 'HR. Muslim dari Abu Hurairah',
    meanings: {
      level1:
        "Mahasuci Allah dan aku memuji-Nya: kalimat yang menyucikan Allah dari segala kekurangan sekaligus menyatakan syukur atas segala nikmat-Nya.",
      level2:
        'Dalam hadits riwayat Muslim dari Abu Hurairah, siapa yang membacanya seratus kali dalam sehari, kesalahannya digugurkan meskipun sebanyak buih di lautan.',
      level3:
        'Saat menunggu, di perjalanan, atau sebelum tidur, hitung dzikir ini dengan jari. Ia adalah tabungan kecil yang terus bertambah.',
    },
  },
  {
    id: 'audzu-bikalimaat',
    title: 'Perlindungan Sore',
    category: 'ketenangan',
    arabic: 'أَعُوْذُ بِكَلِمَاتِ اللهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ',
    transliteration: "A'uudzu bikalimaatillaahit taammaati min syarri maa khalaq.",
    translation: 'Aku berlindung dengan kalimat-kalimat Allah yang sempurna dari kejahatan makhluk yang diciptakan-Nya.',
    defaultTarget: 3,
    sourceRef: 'HR. Muslim, At-Tirmidzi, Ibnu Majah',
    meanings: {
      level1:
        'Permohonan perlindungan dengan kalimat-kalimat Allah yang sempurna dari kejahatan segala sesuatu yang diciptakan-Nya.',
      level2:
        "Dibaca khusus di sore hari, tiga kali. Dalam riwayat At-Tirmidzi, orang yang membacanya ketika sore hari dijaga dari sengatan binatang berbisa pada malam itu.",
      level3:
        'Ketika sore menjelang dan malam tiba, lindungi diri dan keluarga dengan dzikir ini. Ia mengingatkan bahwa penjagaan terbaik ada pada Allah, dari malam hingga pagi.',
    },
  },
]

export function getDzikirById(id: string): DzikirItem {
  return DZIKIR_SEED.find((item) => item.id === id) ?? DZIKIR_SEED[0]
}
